# Portfolio - Jetti Teja Subha Sri

This is a personal portfolio website created using HTML and CSS. It showcases my background, skills, and projects.

## 👩‍🎓 About Me

- B.Tech student (2023–2027) in Electrical and Electronics Engineering
- Interested in software development and Arduino-based embedded systems
- Learning DSA in Python to prepare for product-based companies

## 📂 Sections

- About Me
- Projects
- Skills
- Education
- Contact

## 📡 Live Preview

You can host this portfolio using GitHub Pages or any static site service.

## 🚀 How to Use

1. Clone this repository
2. Open `index.html` in your browser
